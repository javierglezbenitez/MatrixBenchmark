import random


n = 10

def instance_Matrix():
    A = [[random.random() for _ in range(n)] for _ in range(n)]
    B = [[random.random() for _ in range(n)] for _ in range(n)]
    C = [[0 for _ in range(n)] for _ in range(n)]
    return A,B,C


# Método para multiplicar matrices
def test_method(A,B,C):
    for i in range(n):
        for j in range(n):
            for k in range(n):
                C[i][j] += A[i][k] * B[k][k]
    return C



def test_my_function(benchmark):
 A,B,C = instance_Matrix()
 result = benchmark.pedantic(test_method, args=(A,B,C),iterations=1, rounds=10)
    
